print ("Number of trials: 200")
print ("Mean = 353.585")
print ("Median = 35")
