graph = {
 'Oradea': set(['Zerind','Sibiu']),
 'Zerind': set(['Arad','Oradea']),
 'Sibiu': set(['Arad','Rimnicu Vilcea','Fagaras','Oradea']),
 'Arad': set(['Timisoara','Zerind','Sibiu']),
 'Timisoara': set(['Lugoj']),
 'Lugoj': set(['Mehadia']),
 'Mehadia': set(['Drobeta']),
 'Drobeta': set(['Craiova']),
 'Rimnicu Vilcea': set(['Craiova','Pitesti','Sibiu']),
 'Craiova': set(['Drobeta','Rimnicu Vilcea']),
 'Fagaras': set(['Bucharest','Sibiu']),
 'Pitesti': set(['Bucharest','Rimnicu Vilcea']),
 'Bucharest': set(['Giurgiu','Urziceni','Pitesti','Fagaras']),
 'Giurgiu': set(['Bucharest']),
 'Urziceni': set(['Hirsova','Vaslui','Bucharest']),
 'Hirsova': set(['Eforia','Urziceni']),
 'Eforia': set(['Hirsova']),
 'Vaslui': set(['Iasi','Urziceni']),
 'Iasi': set(['Neamt','Vaslui']),
 'Neamt': set(['Iasi'])}
#Defining the method bfs
def bfs(graph, start, end):
#Inserting the start node into the queue
 queue = [(start, [start])]
# Implementing while loop
while queue:
 (vertex, path) = queue.pop(0)
#Recursive function performed
 for next in graph[vertex] - set(path):
 if next == end:
 yield path + [next]
 else:
 queue.append((next, path + [next]))
#Printing the path
print('The Breadth First Serach for the Romania map from Doberta to Urcizeni is:')
print(list(bfs(graph, 'Drobeta', 'Urziceni'))) 