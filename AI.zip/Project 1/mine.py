graph = {
  'Doberta' : ['Criavo','Mehadia'],
  'Criavo' : ['Pitesti', 'Riminiciu'],
  'Mehadia' : ['Lugoj'],
  'Lugoj' : [],
  'Riminiciu' : ['Pitesti'],
  'Pitesti' : ['Bucharest'],
  'Bucharest' : ['Girgui','Urcizeni'],
  'Girgui' : [],
  'Urcizeni' : []}

visited = [] # List for visited nodes.
queue = []     #Initialize a queue

def bfs(visited, graph, node): #function for BFS
  visited.append(node)
  queue.append(node)

  while queue:          # Creating loop to visit each node
    m = queue.pop(0) 
    print (m, end = " ") 

    for neighbour in graph[m]:
      if neighbour not in visited:
        visited.append(neighbour)
        queue.append(neighbour)

# Driver Code
print("The Breadth First Serach for the Romania map from Doberta to Urcizeni is:")
bfs(visited, graph, 'Doberta')# function calling