class Node:
    def __init__(self, name:str, parent:str):
        self.name = name
        self.parent = parent
        self.g = 0  
        self.h = 0 
        self.f = 0 
    def __eq__(self, other):
        return self.name == other.name
    def __lt__(self, other):
         return self.f < other.f
    def __repr__(self):
        return ('({0},{1})'.format(self.name, self.f))

class Graph:
    def __init__(self, dict_graph=None, directed=True):
        self.dict_graph = dict_graph or {}
        self.directed = directed
        if not directed:
            self.make_undirected()
    def make_undirected(self):
        for a in list(self.dict_graph.keys()):
            for (b, dist) in self.dict_graph[a].items():
                self.dict_graph.setdefault(b, {})[a] = dist 
    def connect(self, A, B, distance=1):
        self.dict_graph.setdefault(A, {})[B] = distance
        if not self.directed:
            self.dict_graph.setdefault(B, {})[A] = distance
    def get(self, a, b=None):
        links = self.dict_graph.setdefault(a, {})
        if b is None:
            return links
        else:
            return links.get(b)
    def nodes(self):
        s1 = set([k for k in self.dict_graph.keys()])
        s2 = set([k2 for v in self.dict_graph.values() for k2, v2 in v.items()])
        nodes = s1.union(s2)
        return list(nodes)

def astar_search(graph, heuristics, start, end):
    open = []
    closed = []
    start_node = Node(start, None)
    goal_node = Node(end, None)
    open.append(start_node)
    while len(open) > 0:
        open.sort()
        current_node = open.pop(0)
        closed.append(current_node)
        if current_node == goal_node:
            path = []
            while current_node != start_node:
                path.append(current_node.name)
                current_node = current_node.parent
            path.append(start_node.name)
            return path[::-1]
        neighbors = graph.get(current_node.name)
        for key, value in neighbors.items():
            neighbor = Node(key, current_node)
            if(neighbor in closed):
                continue
            neighbor.g = current_node.g + graph.get(current_node.name, neighbor.name)
            neighbor.h = heuristics.get(neighbor.name)
            neighbor.f = neighbor.g + neighbor.h
            if(add_to_open(open, neighbor) == True):
                open.append(neighbor)
    return None

def add_to_open(open, neighbor):
    for node in open:
        if (neighbor == node and neighbor.f > node.f):
            return False
    return True

def main():
    heuristics_value = {}
    
    heuristics_value['Arad'] = 366
    heuristics_value['Bucharest'] = 0
    heuristics_value['Craiova'] = 160
    heuristics_value['Dobreta'] = 242
    heuristics_value['Eforie'] = 161
    
    heuristics_value['Fagaras'] = 178
    heuristics_value['Giurgiu'] = 77
    heuristics_value['Hirsova'] = 151
    heuristics_value['Lasi'] = 226
    
    heuristics_value['Lugoj'] = 244
    heuristics_value['Mehadia'] = 241
    heuristics_value['Neamt'] = 234
    heuristics_value['Oradea'] = 380
    
    heuristics_value['Pitesti'] = 98
    heuristics_value['Riminicu Vilcea'] = 193
    heuristics_value['Sibiu'] = 253
    heuristics_value['Timisoara'] = 329
    
    heuristics_value['Urziceni'] = 80
    heuristics_value['Vaslui'] = 199
    heuristics_value['Zerind'] = 374
    
    Astar_graph = Graph()
    
    Astar_graph.connect("Arad", "Sibiu", 140)
    Astar_graph.connect("Arad", "Timisoara", 118)
    Astar_graph.connect("Arad", "Zerind", 75)
    
    Astar_graph.connect("Bucharest", "Fagaras", 211)
    Astar_graph.connect("Bucharest", "Giurgiu", 90)
    Astar_graph.connect("Bucharest", "Pitesti", 101)
    Astar_graph.connect("Bucharest", "Urziceni", 85)
    
    Astar_graph.connect("Craiova", "Dobreta", 120)
    Astar_graph.connect("Craiova", "Pitesti", 138)
    Astar_graph.connect("Craiova", "Riminicu Vilcea", 146)
    
    Astar_graph.connect("Dobreta", "Craiova", 120)
    Astar_graph.connect("Dobreta", "Mehadia", 75)
    
    Astar_graph.connect("Eforie", "Hirsova", 86)
    
    Astar_graph.connect("Fagaras", "Bucharest", 211)
    Astar_graph.connect("Fagaras", "Sibiu", 99)
    
    Astar_graph.connect("Giurgiu", "Bucharest", 90)
    
    Astar_graph.connect("Hirsova", "Eforie", 86)
    Astar_graph.connect("Hirsova", "Urziceni", 98)
    
    Astar_graph.connect("Lasi", "Neamt", 87)
    Astar_graph.connect("Lasi", "Vaslui", 92)
    
    Astar_graph.connect("Lugoj", "Mehadia", 70)
    Astar_graph.connect("Lugoj", "Timisoara", 111)
    
    Astar_graph.connect("Mehadia", "Dobreta", 75)
    Astar_graph.connect("Mehadia", "Lugoj", 70)
    
    Astar_graph.connect("Neamt", "Lasi", 87)
    
    Astar_graph.connect("Oradea", "Sibiu", 151)
    Astar_graph.connect("Oradea", "Zerind", 71)
    
    Astar_graph.connect("Pitesti", "Bucharest", 101)
    Astar_graph.connect("Pitesti", "Craiova", 138)
    Astar_graph.connect("Pitesti", "Riminicu Vilcea", 97)

    
    Astar_graph.connect("Riminicu Vilcea", "Craiova", 146)
    Astar_graph.connect("Riminicu Vilcea", "Pitesti", 97)
    Astar_graph.connect("Riminicu Vilcea", "Sibiu", 80)
    
    Astar_graph.connect("Sibiu", "Arad", 140)
    Astar_graph.connect("Sibiu", "Fagaras", 99)
    Astar_graph.connect("Sibiu", "Oradea", 151)
    Astar_graph.connect("Sibiu", "Riminicu Vilcea", 80)
    
    Astar_graph.connect("Timisoara", "Arad", 118)
    Astar_graph.connect("Timisoara", "Lugoj", 111)
    
    Astar_graph.connect("Urziceni", "Bucharest", 85)
    Astar_graph.connect("Urziceni", "Hirsova", 98)
    Astar_graph.connect("Urziceni", "Vaslui", 142)
    
    Astar_graph.connect("Vaslui", "Lasi", 92)
    Astar_graph.connect("Vaslui", "Urziceni", 142)
    
    Astar_graph.connect("Zerind", "Arad", 75)
    Astar_graph.connect("Zerind", "Oradea", 71)
    
    Astar_graph.make_undirected()
    
    #path = astar_search(graph, heuristics, 'Oradea', 'Eforie')
    path = astar_search(Astar_graph, heuristics_value, 'Oradea', 'Eforie')
    print(path)
if __name__ == "__main__": main()