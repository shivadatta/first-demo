graph = {
  "Arad" : ['Sibiu','Timisoara','Zerind'],
  "Bucharest" : ['Fagaras','Giurgiu','Pitesti','Urziceni'],
  "Craiova" : ['Drobeta','Pitesti','RimnicuVilcea'],
  "Drobeta" : ['Craiova','Mehadia'],
  "Eforie" : ['Hirsova'],
  "Fagaras" : ['Bucharest','Sibiu'],
  "Giurgiu" : ['Bucharest'],
  "Hirsova" : ['Eforie','Urziceni'],
  "Iasi" : ['Neamt','Vaslui'],
  "Lugoj" : ['Mehadia','Timisoara'],
  "Mehadia" : ['Drobeta','Lugoj'],
  "Neamt" : ['Iasi'],
  "Oradea" : ['Sibiu','Zerind'],
  "Pitesti" : ['Bucharest','Craiova','RimnicuVilcea'],
  "RimnicuVilcea" : ['Craiova','Pitesti','Sibiu'],
  "Sibiu" : ['Arad','Fagaras','RimnicuVilcea'],
  "Timisoara" : ['Arad','Lugoj'],
  "Urziceni" : ['Bucharest','Hirsova','Vaslui'],
  "Vaslui" : ['Iasi','Urziceni'],
  "Zerind" : ['Arad','Oradea']
}
def dfs_recursive(graph, node, goal, visited):
  if goal in visited:
    return visited;
  else:
     if node not in visited:
        visited.append(node)
        for k in graph[node]:
          dfs_recursive(graph,k,goal, visited)
     return visited
#node=input("Enter Start Node")
#goal=input("Enter Goal Node")
node="Oradea"
goal="Bucharest"
visited = dfs_recursive(graph,node,goal, [])
print(visited)