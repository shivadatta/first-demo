graph = {"Oradea":["Sibiu","Zerind"],
           "Sibiu":["Arad","Fagaras","Rimnicu Vilcea"],
           "Arad":["Sibiu","Timisoara","Zerind"],
            "Sibiu":["Fagaras","Rimiciu"],
            "Fagaras":["Bucharest"],
            "Rimiciu":["Craiova","Pitesti"],
            "Pitesti":[],
            "Zerind":["Arad","Oradea"],
            "Arad":["Timisora"],
           "Timisora":["Lugoj"],
           "Lugoj":["Mehadia"],
           "Mehadia":["Drobeta"],
           "Doberta":["Craiova"]
        
        }
           
def recursive_dfs(graph, source,path = []):

       if source not in path:

           path.append(source)

           if source not in graph:
               # leaf node, backtrack
               return path

           for neighbour in graph[source]:

               path = recursive_dfs(graph, neighbour, path)


       return path

path = recursive_dfs(graph, "Oradea")


print(" ".join(path))