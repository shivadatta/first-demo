import random
#function trail
 def trial():
#Finitialize the coins to 10
   coins = 10
#initialize number_of_plays to O
   number_of_plays = 0
# loop to continue playing until coins=0
   while coins>= 1:
#increment the coins by 1
 coins -=1
#increment the number_of_plays by 1
number_of_plays += 1
#to determine slots randomly among the four choices
slots = [random.choice(["BAR", "BELL", "LEMON", "CHERRY"]) for i in range (3) ]
#to check if the first three values in the slots are same
#if the first three slots have the same value, count=3
#if the first two slots have the same value, count=2.
#otherwise count=1
if slots[0] == slots[1]:
    if slots[1] == slots [2] :
        count = 3
    else:
        count = 2
else:
    count = 1
#if cherry, increment coins with the count.
if slots[0] == "CHERRY":
    coins += count
#check if count=3
elif count == 3:
#if bar and count=3, increment coins by 20.
  if slots[0] == "BAR":
    coins += 20
#if bell and count=3, increment coins by 15.
elif slots[0] == "BELL":
    coins += 15
#if lemon and count=3, increment coins by 5.
else:
    coins += 5
def test (trials):
#to generate some random trails and store them in results
 results = [trial() for i in range (trials)]
#to calculate mean
mean = sum (results) / float (trials)
median = sorted (results) [int (trials/2)]
#to print number of trails.
print ("Number of trials: ", trials)
#to print mean.
print ("Mean: ", mean)
#to print median.
print ("Median: ", median)
# call the function test for 200 trails
test (200)
